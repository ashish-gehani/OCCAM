# Generated from java-escape by ANTLR 4.5
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
package = globals().get("__package__", None)
ischild = len(package)>0 if package is not None else False
if ischild:
    from .ArgvListener import ArgvListener
    from .ArgvVisitor import ArgvVisitor
else:
    from ArgvListener import ArgvListener
    from ArgvVisitor import ArgvVisitor

def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3")
        buf.write(u"\16 \4\2\t\2\4\3\t\3\4\4\t\4\3\2\3\2\3\2\3\2\3\3\3\3")
        buf.write(u"\3\3\7\3\20\n\3\f\3\16\3\23\13\3\3\4\3\4\3\4\3\4\3\4")
        buf.write(u"\3\4\3\4\3\4\3\4\5\4\36\n\4\3\4\2\2\5\2\4\6\2\2\36\2")
        buf.write(u"\b\3\2\2\2\4\f\3\2\2\2\6\35\3\2\2\2\b\t\7\3\2\2\t\n\5")
        buf.write(u"\4\3\2\n\13\7\4\2\2\13\3\3\2\2\2\f\21\5\6\4\2\r\16\7")
        buf.write(u"\5\2\2\16\20\5\6\4\2\17\r\3\2\2\2\20\23\3\2\2\2\21\17")
        buf.write(u"\3\2\2\2\21\22\3\2\2\2\22\5\3\2\2\2\23\21\3\2\2\2\24")
        buf.write(u"\25\7\b\2\2\25\26\7\6\2\2\26\27\7\13\2\2\27\30\7\7\2")
        buf.write(u"\2\30\31\7\n\2\2\31\36\7\f\2\2\32\33\7\t\2\2\33\34\7")
        buf.write(u"\n\2\2\34\36\7\13\2\2\35\24\3\2\2\2\35\32\3\2\2\2\36")
        buf.write(u"\7\3\2\2\2\4\21\35")
        return buf.getvalue()


class ArgvParser ( Parser ):

    grammarFileName = "java-escape"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"'{'", u"'}'", u"','", u"'['", u"']'", 
                     u"'argv'", u"'argc'", u"'='" ]

    symbolicNames = [ u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                      u"<INVALID>", u"<INVALID>", u"ARGV", u"ARGC", u"BINOP", 
                      u"INTEGER", u"STRING", u"LINE_COMMENT", u"WHITE_SPACE" ]

    RULE_constraint = 0
    RULE_atomlist = 1
    RULE_atom = 2

    ruleNames =  [ u"constraint", u"atomlist", u"atom" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    ARGV=6
    ARGC=7
    BINOP=8
    INTEGER=9
    STRING=10
    LINE_COMMENT=11
    WHITE_SPACE=12

    def __init__(self, input):
        super(ArgvParser, self).__init__(input)
        self.checkVersion("4.5")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ConstraintContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(ArgvParser.ConstraintContext, self).__init__(parent, invokingState)
            self.parser = parser

        def atomlist(self):
            return self.getTypedRuleContext(ArgvParser.AtomlistContext,0)


        def getRuleIndex(self):
            return ArgvParser.RULE_constraint

        def enterRule(self, listener):
            if isinstance( listener, ArgvListener ):
                listener.enterConstraint(self)

        def exitRule(self, listener):
            if isinstance( listener, ArgvListener ):
                listener.exitConstraint(self)

        def accept(self, visitor):
            if isinstance( visitor, ArgvVisitor ):
                return visitor.visitConstraint(self)
            else:
                return visitor.visitChildren(self)




    def constraint(self):

        localctx = ArgvParser.ConstraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_constraint)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 6
            self.match(ArgvParser.T__0)
            self.state = 7
            self.atomlist()
            self.state = 8
            self.match(ArgvParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class AtomlistContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(ArgvParser.AtomlistContext, self).__init__(parent, invokingState)
            self.parser = parser

        def atom(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(ArgvParser.AtomContext)
            else:
                return self.getTypedRuleContext(ArgvParser.AtomContext,i)


        def getRuleIndex(self):
            return ArgvParser.RULE_atomlist

        def enterRule(self, listener):
            if isinstance( listener, ArgvListener ):
                listener.enterAtomlist(self)

        def exitRule(self, listener):
            if isinstance( listener, ArgvListener ):
                listener.exitAtomlist(self)

        def accept(self, visitor):
            if isinstance( visitor, ArgvVisitor ):
                return visitor.visitAtomlist(self)
            else:
                return visitor.visitChildren(self)




    def atomlist(self):

        localctx = ArgvParser.AtomlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_atomlist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 10
            self.atom()
            self.state = 15
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==ArgvParser.T__2:
                self.state = 11
                self.match(ArgvParser.T__2)
                self.state = 12
                self.atom()
                self.state = 17
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class AtomContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(ArgvParser.AtomContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ARGV(self):
            return self.getToken(ArgvParser.ARGV, 0)

        def INTEGER(self):
            return self.getToken(ArgvParser.INTEGER, 0)

        def BINOP(self):
            return self.getToken(ArgvParser.BINOP, 0)

        def STRING(self):
            return self.getToken(ArgvParser.STRING, 0)

        def ARGC(self):
            return self.getToken(ArgvParser.ARGC, 0)

        def getRuleIndex(self):
            return ArgvParser.RULE_atom

        def enterRule(self, listener):
            if isinstance( listener, ArgvListener ):
                listener.enterAtom(self)

        def exitRule(self, listener):
            if isinstance( listener, ArgvListener ):
                listener.exitAtom(self)

        def accept(self, visitor):
            if isinstance( visitor, ArgvVisitor ):
                return visitor.visitAtom(self)
            else:
                return visitor.visitChildren(self)




    def atom(self):

        localctx = ArgvParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_atom)
        try:
            self.state = 27
            token = self._input.LA(1)
            if token in [ArgvParser.ARGV]:
                self.enterOuterAlt(localctx, 1)
                self.state = 18
                self.match(ArgvParser.ARGV)
                self.state = 19
                self.match(ArgvParser.T__3)
                self.state = 20
                self.match(ArgvParser.INTEGER)
                self.state = 21
                self.match(ArgvParser.T__4)
                self.state = 22
                self.match(ArgvParser.BINOP)
                self.state = 23
                self.match(ArgvParser.STRING)

            elif token in [ArgvParser.ARGC]:
                self.enterOuterAlt(localctx, 2)
                self.state = 24
                self.match(ArgvParser.ARGC)
                self.state = 25
                self.match(ArgvParser.BINOP)
                self.state = 26
                self.match(ArgvParser.INTEGER)

            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx




