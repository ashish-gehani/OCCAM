# Generated from java-escape by ANTLR 4.5
from antlr4 import *

# This class defines a complete listener for a parse tree produced by ArgvParser.
class ArgvListener(ParseTreeListener):

    # Enter a parse tree produced by ArgvParser#constraint.
    def enterConstraint(self, ctx):
        pass

    # Exit a parse tree produced by ArgvParser#constraint.
    def exitConstraint(self, ctx):
        pass


    # Enter a parse tree produced by ArgvParser#atomlist.
    def enterAtomlist(self, ctx):
        pass

    # Exit a parse tree produced by ArgvParser#atomlist.
    def exitAtomlist(self, ctx):
        pass


    # Enter a parse tree produced by ArgvParser#atom.
    def enterAtom(self, ctx):
        pass

    # Exit a parse tree produced by ArgvParser#atom.
    def exitAtom(self, ctx):
        pass


