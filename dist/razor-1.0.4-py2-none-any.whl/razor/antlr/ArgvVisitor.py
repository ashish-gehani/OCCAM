# Generated from java-escape by ANTLR 4.5
from antlr4 import *

# This class defines a complete generic visitor for a parse tree produced by ArgvParser.

class ArgvVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by ArgvParser#constraint.
    def visitConstraint(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ArgvParser#atomlist.
    def visitAtomlist(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ArgvParser#atom.
    def visitAtom(self, ctx):
        return self.visitChildren(ctx)


